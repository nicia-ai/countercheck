# Countercheck evaluation

Backend: **decider**. Track: **development**. Manifest SHA-256: `114ee3ca8ff9960fc2146bf7bca19f38284281812c9cec27e25e9815746337b6`.

Supplied-evidence pair adaptation; this is not an end-to-end retrieval score or production release qualification.

Packing: `pair_isolation`; envelope failure: `exclude_entire_submitted_batch`; automatic repacking: false. Batched coverage is specific to this submitted-batch protocol and is not an isolated-pair quality score.

Deadline: 3000 ms, `kernel_compilation_and_provider_total`, `route_default`. Production qualification: not assessed.

| Measure | Value |
|---|---:|
| Pair observations | 200 |
| Positive / negative | 67 / 133 |
| Precision | 0.9783 |
| Recall (uncertainty/failures miss) | 0.6716 |
| F1 | 0.7965 |
| Definitive coverage | 0.6350 |
| Clear-negative coverage | 0.6090 |
| False positive rate | 0.0075 |
| AUROC | 0.9859 |
| PR-AUC (average precision) | 0.9733 |
| Scored prevalence | 0.3367 |
| Brier | 0.0517 |
| Errors / excluded | 1 / 0 |

Probabilistic metrics exclude missing distributions; their denominator is 199. Positive recall and coverage retain errors, exclusions and uncertainty. Pair-weighted latency is diagnostic; it is not a deployed request-capacity measurement.

JSON contains complete per-pair distributions, original labels, dataset/native-negative slices, pass summaries, calibration bins, risk/coverage, Wilson intervals and group bootstrap intervals. Cost reservations are not measured charges; unavailable usage/cost stays unknown. No production gates are certified by this report.

Execution observations: 200; completed: 199; errors: 1; excluded: 0. Expected-uncertain synthetic fixtures excluded from binary metrics: 0. Expected-verdict diagnostics: 0/0 (synthetic only).
