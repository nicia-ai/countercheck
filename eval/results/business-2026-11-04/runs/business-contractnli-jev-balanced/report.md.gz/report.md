# Countercheck evaluation

Backend: **jev**. Track: **development**. Manifest SHA-256: `4906005f4843b97a1cc6f256f62467cced5183965a0bafa9d713ee0099326311`.

Supplied-evidence pair adaptation; this is not an end-to-end retrieval score or production release qualification.

Packing: `pair_isolation`; envelope failure: `exclude_entire_submitted_batch`; automatic repacking: false. Batched coverage is specific to this submitted-batch protocol and is not an isolated-pair quality score.

Deadline: 3000 ms, `kernel_compilation_and_provider_total`, `route_default`. Production qualification: not assessed.

| Measure | Value |
|---|---:|
| Pair observations | 199 |
| Positive / negative | 26 / 173 |
| Precision | 0.8571 |
| Recall (uncertainty/failures miss) | 0.4615 |
| F1 | 0.6000 |
| Definitive coverage | 0.6583 |
| Clear-negative coverage | 0.6647 |
| False positive rate | 0.0116 |
| AUROC | 0.9336 |
| PR-AUC (average precision) | 0.7586 |
| Scored prevalence | 0.1307 |
| Brier | 0.0570 |
| Errors / excluded | 0 / 0 |

Probabilistic metrics exclude missing distributions; their denominator is 199. Positive recall and coverage retain errors, exclusions and uncertainty. Pair-weighted latency is diagnostic; it is not a deployed request-capacity measurement.

JSON contains complete per-pair distributions, original labels, dataset/native-negative slices, pass summaries, calibration bins, risk/coverage, Wilson intervals and group bootstrap intervals. Cost reservations are not measured charges; unavailable usage/cost stays unknown. No production gates are certified by this report.

Execution observations: 199; completed: 199; errors: 0; excluded: 0. Expected-uncertain synthetic fixtures excluded from binary metrics: 0. Expected-verdict diagnostics: 0/0 (synthetic only).
