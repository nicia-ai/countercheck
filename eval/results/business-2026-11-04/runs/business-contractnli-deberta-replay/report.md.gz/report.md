# Countercheck evaluation

Backend: **replay**. Track: **development**. Manifest SHA-256: `4906005f4843b97a1cc6f256f62467cced5183965a0bafa9d713ee0099326311`.

Supplied-evidence pair adaptation; this is not an end-to-end retrieval score or production release qualification.

Packing: `recorded_predictions`; envelope failure: `as_recorded`; automatic repacking: false. Batched coverage is specific to this submitted-batch protocol and is not an isolated-pair quality score.

Deadline: not applied (replay), `not_applied_replay`, `not_applied_replay`. Production qualification: not assessed.

| Measure | Value |
|---|---:|
| Pair observations | 199 |
| Positive / negative | 26 / 173 |
| Precision | 0.4815 |
| Recall (uncertainty/failures miss) | 0.5000 |
| F1 | 0.4906 |
| Definitive coverage | 1.0000 |
| Clear-negative coverage | 0.9191 |
| False positive rate | 0.0809 |
| AUROC | 0.8304 |
| PR-AUC (average precision) | 0.4812 |
| Scored prevalence | 0.1307 |
| Brier | 0.1224 |
| Errors / excluded | 0 / 0 |

Probabilistic metrics exclude missing distributions; their denominator is 199. Positive recall and coverage retain errors, exclusions and uncertainty. Pair-weighted latency is diagnostic; it is not a deployed request-capacity measurement.

JSON contains complete per-pair distributions, original labels, dataset/native-negative slices, pass summaries, calibration bins, risk/coverage, Wilson intervals and group bootstrap intervals. Cost reservations are not measured charges; unavailable usage/cost stays unknown. No production gates are certified by this report.

Execution observations: 199; completed: 199; errors: 0; excluded: 0. Expected-uncertain synthetic fixtures excluded from binary metrics: 0. Expected-verdict diagnostics: 0/0 (synthetic only).
