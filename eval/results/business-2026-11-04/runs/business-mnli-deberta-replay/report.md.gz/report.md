# Countercheck evaluation

Backend: **replay**. Track: **development**. Manifest SHA-256: `114ee3ca8ff9960fc2146bf7bca19f38284281812c9cec27e25e9815746337b6`.

Supplied-evidence pair adaptation; this is not an end-to-end retrieval score or production release qualification.

Packing: `recorded_predictions`; envelope failure: `as_recorded`; automatic repacking: false. Batched coverage is specific to this submitted-batch protocol and is not an isolated-pair quality score.

Deadline: not applied (replay), `not_applied_replay`, `not_applied_replay`. Production qualification: not assessed.

| Measure | Value |
|---|---:|
| Pair observations | 200 |
| Positive / negative | 67 / 133 |
| Precision | 0.9538 |
| Recall (uncertainty/failures miss) | 0.9254 |
| F1 | 0.9394 |
| Definitive coverage | 1.0000 |
| Clear-negative coverage | 0.9774 |
| False positive rate | 0.0226 |
| AUROC | 0.9937 |
| PR-AUC (average precision) | 0.9869 |
| Scored prevalence | 0.3350 |
| Brier | 0.0336 |
| Errors / excluded | 0 / 0 |

Probabilistic metrics exclude missing distributions; their denominator is 200. Positive recall and coverage retain errors, exclusions and uncertainty. Pair-weighted latency is diagnostic; it is not a deployed request-capacity measurement.

JSON contains complete per-pair distributions, original labels, dataset/native-negative slices, pass summaries, calibration bins, risk/coverage, Wilson intervals and group bootstrap intervals. Cost reservations are not measured charges; unavailable usage/cost stays unknown. No production gates are certified by this report.

Execution observations: 200; completed: 200; errors: 0; excluded: 0. Expected-uncertain synthetic fixtures excluded from binary metrics: 0. Expected-verdict diagnostics: 0/0 (synthetic only).
